// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include <stdexcept>   // adding this so we can use standard exceptions like std::runtime_error and std::invalid_argument
#include <exception>   // std::exception
#include <string>

// I made a small custom exception class so we can throw something specific and catch it first in main
class CustomAppException : public std::runtime_error
{
public:
    explicit CustomAppException(const std::string& message)
        : std::runtime_error(message) {}
};

bool do_even_more_custom_application_logic()
{
    // TODO: Throw any standard exception
    // show a standard exception being thrown and caught,
    // I�m throwing runtime_error 
    std::cout << "Running Even More Custom Application Logic." << std::endl;

    throw std::runtime_error("Standard exception: something went wrong in do_even_more_custom_application_logic().");

    // return true; // unreachable, but leaving the structure alone conceptually
}

void do_custom_application_logic()
{
    // TODO: Wrap the call to do_even_more_custom_application_logic()
    //  with an exception handler that catches std::exception, displays
    //  a message and the exception.what(), then continues processing
    std::cout << "Running Custom Application Logic." << std::endl;

    // Wrapping just this call in a try/catch lets the program keep going instead of crashing,
    
    try
    {
        if (do_even_more_custom_application_logic())
        {
            std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
        }
    }
    catch (const std::exception& ex)
    {
        // This shows the user what happened
        
        std::cout << "Caught std::exception inside do_custom_application_logic(), continuing safely." << std::endl;
        std::cout << "  what(): " << ex.what() << std::endl;
    }

    // TODO: Throw a custom exception derived from std::exception
    //  and catch it explictly in main
    // Throwing a custom exception here gives main something specific to catch first.
    throw CustomAppException("Custom exception: issue detected in do_custom_application_logic().");

    std::cout << "Leaving Custom Application Logic." << std::endl;
}

float divide(float num, float den)
{
    // TODO: Throw an exception to deal with divide by zero errors using
    //  a standard C++ defined exception
    // If den is zero, we don�t want to return infinity or crash,
    // we want to throw somethingxplains the problem.
    if (den == 0.0f)
    {
        throw std::invalid_argument("Divide by zero error in divide().");
    }

    return (num / den);
}

void do_division() noexcept
{
    //  TODO: create an exception handler to capture ONLY the exception thrown
    //  by divide.
    //
    // This function is marked noexcept, so if an exception escapes this function,
    // the program will just terminate, so we have to catch it right heree

    float numerator = 10.0f;
    float denominator = 0;

    try
    {
        auto result = divide(numerator, denominator);
        std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
    }
    catch (const std::invalid_argument& ex)
    {
        // Catching ONLY the specific type we threw in divide 
        std::cout << "Division exception caught, app did not crash." << std::endl;
        std::cout << "  what(): " << ex.what() << std::endl;
    }
}

int main()
{
    std::cout << "Exceptions Tests!" << std::endl;

    // TODO: Create exception handlers that catch (in this order):
    //  your custom exception
    //  std::exception
    //  uncaught exception
    //  that wraps the whole main function, and displays a message to the console.
    //
    // Wrapping the main flow means nothing should crash �silently� anymore,
    // we should always print something helpful for the user.
    try
    {
        do_division();
        do_custom_application_logic();
    }
    catch (const CustomAppException& ex)
    {
        // Catching our custom exception first gives us the most specific message.
        std::cout << "Caught CustomAppException in main." << std::endl;
        std::cout << "  what(): " << ex.what() << std::endl;
    }
    catch (const std::exception& ex)
    {
        // This catches other standard exceptions we didn�t catch above
        std::cout << "Caught std::exception in main." << std::endl;
        std::cout << "  what(): " << ex.what() << std::endl;
    }
    catch (...)
    {
        // Catch-all is basically the last line of defense
        
        std::cout << "Caught an unknown exception in main (catch-all)." << std::endl;
    }

    return 0;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
