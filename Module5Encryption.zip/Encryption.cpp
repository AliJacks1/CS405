// Encryption.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <cassert>
#include <ctime>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

// NOTE: XOR "encryption" is not real-world secure encryption, but it's perfect for showing
// how encrypting and decrypting works in a simple way for this assignment.

std::string encrypt_decrypt(const std::string& source, const std::string& key)
{
    // get lengths now instead of calling the function every time.
    // this would have most likely been inlined by the compiler, but design for perfomance.
    const auto key_length = key.length();
    const auto source_length = source.length();

    // assert that our input data is good
    assert(key_length > 0);
    assert(source_length > 0);

    std::string output = source;

    // loop through the source string char by char
    for (size_t i = 0; i < source_length; ++i)
    {
        // TODO: student need to change the next line from output[i] = source[i]
        // The main idea is that the key repeats, so we wrap around with i % key_length.
        // XOR the current source char with the matching key char.
        output[i] = static_cast<char>(source[i] ^ key[i % key_length]);
    }

    // our output length must equal our source length
    assert(output.length() == source_length);

    // return the transformed string
    return output;
}

std::string read_file(const std::string& filename)
{
    std::string file_text;

    // TODO: implement loading the file into a string
    // Opening the file in a simple way, then reading the entire thing into one string.
    std::ifstream in(filename, std::ios::in);
    if (!in.is_open())
    {
        // If the file nott found, this iis because it's not in x64\\Debug.
        //catch.
        std::cerr << "Could not open file: " << filename << std::endl;
        return file_text;
    }

    std::ostringstream buffer;
    buffer << in.rdbuf();
    file_text = buffer.str();

    return file_text;
}

std::string get_student_name(const std::string& string_data)
{
    std::string student_name;

    // find the first newline
    size_t pos = string_data.find('\n');
    // did we find a newline
    if (pos != std::string::npos)
    { // we did, so copy that substring as the student name
        student_name = string_data.substr(0, pos);
    }

    return student_name;
}

void save_data_file(const std::string& filename, const std::string& student_name, const std::string& key, const std::string& data)
{
    //  TODO: implement file saving
    //  file format
    //  Line 1: student name
    //  Line 2: timestamp (yyyy-mm-dd)
    //  Line 3: key used
    //  Line 4+: data

    std::ofstream out(filename, std::ios::out | std::ios::trunc);
    if (!out.is_open())
    {
        std::cerr << "Could not write to file: " << filename << std::endl;
        return;
    }

    // timestamp (yyyy-mm-dd)
    // Keeping it straightforward, using local time and formatting it manually.
    std::time_t now = std::time(nullptr);
    std::tm local_tm{};
#ifdef _WIN32
    localtime_s(&local_tm, &now);
#else
    local_tm = *std::localtime(&now);
#endif

    int year = local_tm.tm_year + 1900;
    int month = local_tm.tm_mon + 1;
    int day = local_tm.tm_mday;

    out << student_name << "\n";

    // format with leading zeros for month/day
    out << year << "-";
    out << (month < 10 ? "0" : "") << month << "-";
    out << (day < 10 ? "0" : "") << day << "\n";

    out << key << "\n";

    // data starts line 4+
    out << data;

    out.close();
}

int main()
{
    std::cout << "Encyption Decryption Test!" << std::endl;

    // input file format
    // Line 1: <students name>
    // Line 2: <Lorem Ipsum Generator website used> https://pirateipsum.me/ (could be https://www.lipsum.com/ or one of https://www.shopify.com/partners/blog/79940998-15-funny-lorem-ipsum-generators-to-shake-up-your-design-mockups)
    // Lines 3+: <lorem ipsum generated with 3 paragraphs>

    const std::string file_name = "inputdatafile.txt";
    const std::string encrypted_file_name = "encrypteddatafile.txt";
    const std::string decrypted_file_name = "decrytpteddatafile.txt"; 
    const std::string source_string = read_file(file_name);
    const std::string key = "password";

    // get the student name from the data file
    const std::string student_name = get_student_name(source_string);

    // encrypt sourceString with key
    const std::string encrypted_string = encrypt_decrypt(source_string, key);

    // save encrypted_string to file
    save_data_file(encrypted_file_name, student_name, key, encrypted_string);

    // decrypt encryptedString with key
    const std::string decrypted_string = encrypt_decrypt(encrypted_string, key);

    // save decrypted_string to file
    save_data_file(decrypted_file_name, student_name, key, decrypted_string);

    std::cout << "Read File: " << file_name << " - Encrypted To: " << encrypted_file_name << " - Decrypted To: " << decrypted_file_name << std::endl;

    // students submit input file, encrypted file, decrypted file, source code file, and key used
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
