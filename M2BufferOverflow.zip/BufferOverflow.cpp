// BufferOverflow.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iomanip>
#include <iostream>
#include <string>
#include <cstring>

int main()
{
    std::cout << "Buffer Overflow Example" << std::endl;

    // TODO: The user can type more than 20 characters and overflow the buffer, resulting in account_number being replaced -
    //  even though it is a constant and the compiler buffer overflow checks are on.
    //  You need to modify this method to prevent buffer overflow without changing the account_number
    //  variable, and its position in the declaration. It must always be directly before the variable used for input.
    //  You must notify the user if they entered too much data.

    const std::string account_number = "CharlieBrown42";
    char user_input[20];

    // std::string first so we can check how long the input is
    std::string temp_input;
    std::cout << "Enter a value: ";
    std::cin >> temp_input;

    // If  more characters typed tthan our fixed buffer can hold, we will truncate it
    bool too_long = temp_input.size() >= sizeof(user_input);

    // Copy only as many characters as will fit in user_input, leaving room for the null terminator
    strncpy_s(user_input, sizeof(user_input), temp_input.c_str(), sizeof(user_input) - 1);
    user_input[sizeof(user_input) - 1] = '\0';  // make sure it is always null terminated

    if (too_long)
    {
        // Let user know input was longer than the buffer, so we cut it off safely
        std::cout << "Warning: youu entered more characters than allowed, so the value was truncated.." << std::endl;
    }

    std::cout << "You entered: " << user_input << std::endl;
    std::cout << "Account Number = " << account_number << std::endl;
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
