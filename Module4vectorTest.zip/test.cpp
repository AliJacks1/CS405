// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"

#include <memory>
#include <vector>
#include <cassert>
#include <stdexcept>
#include <algorithm>

// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        // small cast here just to avoid the warning about time_t converting to unsigned int
        srand(static_cast<unsigned int>(time(nullptr)));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
 // TEST_F(CollectionTest, AlwaysFail)
 // {
 //   FAIL();
 // }

 // TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // starting state should be empty
    ASSERT_TRUE(collection->empty());
    ASSERT_EQ(collection->size(), 0u);

    add_entries(1);

    // after adding 1, it should not be empty, and size should be 1
    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 1u);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    ASSERT_TRUE(collection->empty());

    add_entries(5);

    EXPECT_FALSE(collection->empty());
    EXPECT_EQ(collection->size(), 5u);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeAndCapacityAreAlwaysAtLeastSize)
{
    // I combined the max_size and capacity checks into one test since they follow the same pattern,
    // and it keeps the total test count exactly where the assignment wants it.

    // 0 entries
    EXPECT_GE(collection->max_size(), collection->size());
    EXPECT_GE(collection->capacity(), collection->size());

    // 1 entry
    add_entries(1);
    EXPECT_GE(collection->max_size(), collection->size());
    EXPECT_GE(collection->capacity(), collection->size());

    collection->clear();

    // 5 entries
    add_entries(5);
    EXPECT_GE(collection->max_size(), collection->size());
    EXPECT_GE(collection->capacity(), collection->size());

    collection->clear();

    // 10 entries
    add_entries(10);
    EXPECT_GE(collection->max_size(), collection->size());
    EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, ResizeIncreasesCollectionSize)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    collection->resize(10);

    EXPECT_EQ(collection->size(), 10u);
    EXPECT_GE(collection->capacity(), collection->size());
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, ResizeDecreasesCollectionSize)
{
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u);

    collection->resize(5);

    EXPECT_EQ(collection->size(), 5u);
    EXPECT_FALSE(collection->empty());
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, ResizeToZeroMakesCollectionEmpty)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    collection->resize(0);

    EXPECT_EQ(collection->size(), 0u);
    EXPECT_TRUE(collection->empty());
}

// TODO: Create a test to verify clear erases the collection
// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, ClearAndEraseBothRemoveElements)
{
    // clear() scenario
    add_entries(5);
    ASSERT_FALSE(collection->empty());

    collection->clear();

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);

    // erase(begin,end) scenario
    add_entries(10);
    ASSERT_EQ(collection->size(), 10u);

    // erase returns an iterator, storing it avoids the [[nodiscard]] warning
    auto it = collection->erase(collection->begin(), collection->end());
    (void)it;

    EXPECT_TRUE(collection->empty());
    EXPECT_EQ(collection->size(), 0u);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotSize)
{
    add_entries(5);

    const size_t originalSize = collection->size();
    const size_t originalCapacity = collection->capacity();

    // reserve should not change size, it should only affect capacity
    collection->reserve(originalCapacity + 50);

    EXPECT_EQ(collection->size(), originalSize);
    EXPECT_GE(collection->capacity(), originalCapacity + 50);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, AtThrowsOutOfRangeWhenIndexOutOfBounds)
{
    add_entries(5);
    ASSERT_EQ(collection->size(), 5u);

    // valid indices are 0-4, so 5 should throw
    EXPECT_THROW(collection->at(5), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative

// Positive: verify front() and back() match what we pushed
TEST_F(CollectionTest, FrontAndBackReturnExpectedValuesAfterPushBack)
{
    ASSERT_TRUE(collection->empty());

    collection->push_back(42);
    collection->push_back(99);

    EXPECT_EQ(collection->front(), 42);
    EXPECT_EQ(collection->back(), 99);
    EXPECT_EQ(collection->size(), 2u);
}

// Negative: calling at() on an empty vector should throw out_of_range
TEST_F(CollectionTest, AtThrowsOutOfRangeOnEmptyVector)
{
    ASSERT_TRUE(collection->empty());
    EXPECT_THROW(collection->at(0), std::out_of_range);
}
